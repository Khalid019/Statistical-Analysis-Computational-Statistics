#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Solution 4.(b):
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
U=runif(1)
if(U < 0.5){
  X <- sqrt(2*U)
}else{
  X <- 2-sqrt(2*(1-U))
}
X

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Solution:4.(c)
# improve this code for n values, say n=1000
# generate the random number:
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
set.seed(1000)
n=1000
x <-c()
for(i in 1:n){
  U=runif(1)
  if(U < 0.5){
    x[i]<- sqrt(2*U)
  }else{
    x[i] <- 2-sqrt(2*(1-U))
  }
}

# print the pdf n values:
x
# mean of X
mean(x)

# Standard deviation of X:
sd(x)
