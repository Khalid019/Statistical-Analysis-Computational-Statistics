rm(list = ls())
game_crap <- function(n){
  i<-1
  
  # 5 games output:
  cat("5 games output: \n")
  
  for(i in 1:n){
    x1 <- ceiling(6*runif(1))  # x1 is the first dice
    x2 <- ceiling(6*runif(1))  # x2 is the second dice
    x <- sum(x1,x2)            # x: sum of two dice
    
    # condition: x equal to 7 or 8 
    if( x == 7 | x == 11){
      cat("you win \n")
    }else{
      cat("You lose roll again \n")
    }
    #i <- i+1
  }
}

# Output of function
game_crap(5)
      
