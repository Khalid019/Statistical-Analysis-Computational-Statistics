rm(list = ls())
#>>>>>>>>>>>>>>>>> composition approach:

U1 =runif(1, min=0, max=1)
U2 =runif(1, min=0, max=1)
x=numeric()
if(U1 < 0.5){
  x = 1+ log(U2)/(1/2)
}else{
  x = 1+ log(U2)/(2/3)
}

#output
x
  



