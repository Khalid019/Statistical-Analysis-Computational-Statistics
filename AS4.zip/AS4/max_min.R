# random created 20 in a vector x:
x <- runif(20)

Max_of_a_vector <- function(x) {
  # set the target value is the value of a random vector, x:
   maX <- x[1] 
   # i has taken values 2, 3, ..., length(x)
  for (i in (seq_along(x[-1]) + 1)){
    #  comparison with curent target
    if(x[i] > maX){ 
    #  update target in each case
    maX <- x[i]
    }
  }
  maX
}