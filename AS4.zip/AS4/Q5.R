rm(list = ls())
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Newton-Rapson Method
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

nrmethod <- function(startingvalue, tol, itmax){

  xold <- startingvalue
  cat("starting value", xold, "\n")

  f <- function(x){exp(x) - 3*x^2}
  df <- function(x){exp(x)- 6 *x}
  xnew <- xold - f(xold)/df(xold)

  it <- 0
  while (it < itmax) {
    xnew <- xold - f(xold)/df(xold)
    it <- it + 1
    if(abs(xnew-xold) < tol) break
    xold =xnew
  }
  list(root=xnew, it=it)
}

#output
nrmethod(2, 1e-2, 50)
