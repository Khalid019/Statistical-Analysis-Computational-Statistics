# Assignment 1, Stat 6545: Computational Statistics


# Solution 1:

# Algorithm:
# N <- number of payments monthly
# A <- repayment monthly
# P <- principal loan
# I <- interest rate yearly -> convert monthly
# A=250,  P= -5000, r=0.036 yearly

# Creating a funtion for  monthly payment

Payment = function(A, P, r){
    N=  0            # initial value N=0 <- number of payment
    while(P <= 0){
    
      I = (r/12) * P   # monthly interest of principal: I  
      P = P + I + A    # P is the principal value 
      N= N + 1           # N is the number of monthly payment 
    
      cat(" Number of times(monthly) =",N," Interest rate (monthly) =", I, " Repayment=", A, " Principal value= ",P, "\n")
    
      if(P> 0){
      cat("Loan provider will give me back this amount because this is my extra money: ", P)}
  }
}

# Claculating monthly payment step by step for giving fixed values, where payment is a function:
Payment(A=250 ,  P= -5000, r=0.036)

#.............................................................................................................................................
# Solution 2(a): Simulation the rolling of a die.

# Algorithm:
# betting at least one six <- in a four throws <- number of throws i from 1 to 4 (use for loop here)
# print out whether win or lose <- die_face == 6 <- you win or die_face != 6 <- you lose (here we can use if and else if condition to compare)


# die_face is a variable after rolling a die
die_face <- ceiling (6*runif(1))       

# Now use the condition for betting: (four rolling)

for (i in 1:4){
	print(paste("Your result is ", die_face))
	
	# if/else if condion for die_face == 6
	if(die_face == 6){
	  print("You win because your result is six !")
	  break	
	} else if(die_face != 6 & i != 4){		
		print("You can roll again: ")
		die_face = ceiling (6*runif(1))
	} else if(die_face != 6 & i== 4){
			print("You are loser!")
	}
  }

#...............................................................................................................................................
# Solution 2(b): write the above program with function

# Algorithm: 
# here by default n=4, number of rolling
# die_face == 6 <- you win <- return(TRUE)
# die_face != 6 <- you lose <- return(FALSE)


# Create a function for above algorithm:
# I will set up input argument value of n=4 in a function like as below:
rolling_out <- function(n = 4){

	# die_face is a variable after rolling a die
	die_face <- ceiling (6*runif(1))       

	# Now use the condition for betting: (four rolling)

	for (i in 1:n){
	print(paste("Your result is ", die_face))
	
	# if/else if condion for die_face == 6 and add return true
	if(die_face == 6){
	  print("You win because your result is six !")
	  return(TRUE)
	  break	
	} 
	else if(die_face != 6 & i != n){		
		print("You can roll again: ")
		die_face = ceiling (6*runif(1))
	} 
	else if (die_face != 6 & i== n){
		print("You are loser!")
		return(FALSE)}
    }
  }

#output of the function:
rolling_out()

# rolling_out(4)

#................................................................................................................................................

# Solution 2(c):

# Algorithm:
# use function from 2(b)< that uses six's <- simulate N plays games
# Run program <- n=4 and N=100, 1000, 10000 for each n value
# probabilty <- no six's for (5/6)^n
# probability <- getting at least one six's  is 1-(5/6)^n
# calculate <- theoritical probability, simulation estimate & difference between them.

rolling_out <- function(n = 4){

	# die_face is a variable after rolling a die
	die_face <- ceiling (6*runif(1))       

	# Now use the condition for betting: (four rolling)

	for (i in 1:n){
	
	# if/else if condion for die_face == 6 and add return true
	if(die_face == 6){
	  return(TRUE)
	  break	
	} else if(die_face != 6 & i != n){		
		die_face = ceiling (6*runif(1))
	} else if (die_face != 6 & i== n){
		return(FALSE)
	}
  }
  }

simulation_N <- function(N){
	# determine the proportion of time that you win bet
	# set initial value for True (T) and False (F)
	T <- 0	
	F <- 0
	
	# output set
	#T_or_F <- 0
	# call rolling_out function by T_or_F (TRUE_or_FALSE)
	for(i in 1:N){
	T_or_F <- rolling_out()
	if(T_or_F == FALSE){
	F = F+1
	}else if(T_or_F == TRUE){
	T = T +1
	}
	}	
	total_plays <- F + T
	actualtime_win <- T/total_plays
	theoriticaltime_win <- 1-((5/6)^4)
	diff_time <- abs(actualtime_win - theoriticaltime_win)

	# use print function
	print(paste("total number of plays (N):", total_plays))
	print(paste("Actual proportion of time for win:", actualtime_win))
	print(paste("Theoritical proportion of time for win:", theoriticaltime_win))
	print(paste("Difference of actual and theoritical proportion of time for win:",diff_time))		

}

simulation_N(100)
#simulation_N(1000) 
#simulation_N(10000)


#.............................................................................................................................................. 

# Sulotion 3: 

# Algorithom:
# solve <- by recusive function <- nCr = n-1Cr + n-1Cr-1 (n>r>0)
# condition <- nCn = nC0 = 1
# consider a element x of a set n
# Any subset of r items either contains x or it does not
# subsets of r items that do not contain x = n-1Cr
# subsets of r items that contain x = n-1Cr-1

# write down a functon called nCr
# n and r must be integer where  n>r
	nCr <- function(n, r) {
	# set up the base condition nCn = nC0 =1
	if(n<r){
	print("Invalid Input")
	}else if (r == 0 | r == n){
	return (1)
	}else return (nCr(n-1, r-1) + nCr(n-1, r))    # recursive call function
	 
}
  
nCr(4, 2)

#............................................................................................................................................

# Solution 4:

# Algorithm:
# Find <- apply each distribution such as Normal, chi square, t distribution and gamma distribution
# test the p-values with alpha = 0.05
# check <- True/False values

# create a function for normal distribution:

Normal_Dis <- function(){
	# initilize the mean square total (MST)and mean square error(MSE) 
	MST <- numeric(1000)
	MSE <- numeric(1000)
	p.value <- numeric(1000)
	Fisher_value <- numeric(1000)
	
	# set up the alpha value and initial counting value
	alpha <- 0.05
	# count the number
	cnt_number <- 0
	cnt_numb <- 0
	a <- 0
	# quantile
	quant <- qf(1-alpha, 3, 12)
	

	# create a loop for 1000 times
	for(k in 1:1000){
		cdata <- numeric(0)
		# SSTotal
		SST <- 0
		# SSTreatment
		SSTreatment <- 0
		# sum square error
		SSE <- 0
		# number of group
		n <- 4
		# mean and std
		y_mean <- numeric(n)
		std <- numeric(n)
		
		# now create rnorm for 16 value
		cdata <- rnorm(16, mean=0, sd=1)
		# create a matrix
		M <- matrix(cdata, n, n)
		N <- length(cdata)
		mu <- mean(cdata)
		
		for(i in 1:n){
			y_mean[i] <- mean(M[i,])
			std[i] <- var(M[i,])
		}

		# now SST define
		for(i in 1:n){
			for(j in 1:n){
				SST <- SST+(M[i,j]-mu)^2	
			}
			        SSTreatment <- SSTreatment + n*(y_mean[i]-mu)^2
				SSE <- SSE + (n-1)*std[i]
		}
		#mean square total:
		MST[k] <- SSTreatment/(n-1)
		#mean square error:
		MSE[k] <- SSE/(N-n)
		#p value
		Fisher_value[k] = MST[k]/MSE[k]
		p.value[k] <- pf(Fisher_value[k], n-1, N-n)  
		
		# condition p.value with alpha
		if(p.value[k] <= alpha){
		cnt_number = cnt_number + 1
		}
		
		if(p.value[k] > alpha){
		cnt_numb = cnt_numb + 1
		}

		if(Fisher_value[k] > quant){
		a = a+ 1
		}			
	}  
	
	# return value
	return(cat("Count TRUE p_values number when less than or equalt to(<=) alpha(0.05)= ", cnt_number, ", Count False (>0.05) values= ",cnt_numb, "\n"))

}

## t-distribution:

t_Dis <- function(){
	# initilize the mean square total (MST)and mean square error(MSE) 
	MSE <- numeric(1000)
	MST <- numeric(1000)
	p.value <- numeric(1000)
	Fisher_value <- numeric(1000)
	
	# set up the alpha value and initial counting value
	alpha <- 0.05
	cnt_number <- 0
	cnt_numb <- 0
	a <- 0
	# quantile
	quant <- qf(1-alpha, 3, 12)
	

	# create a loop for 1000 times
	for(k in 1:1000){
		cdata <- numeric(0)
		# SSTotal
		SST <- 0
		# SSTreatment
		SSTreatment <- 0
		# sum square error
		SSE <- 0
		n <- 4
		# mean and std
		y_mean <- numeric(n)
		std <- numeric(n)
		
		# now create rnorm for 16 value
		cdata <- rt(16, df =3) # degree of freedom 3
		cdata = cdata/sqrt(3)
		# create a matrix
		M <- matrix(cdata, n, n)
		N <- length(cdata)
		mu <- mean(cdata)
		
		for(i in 1:n){
			y_mean[i] <- mean(M[i,])
			std[i] <- var(M[i,])
		}

		# now SST define
		for(i in 1:n){
			for(j in 1:n){
				SST <- SST+(M[i,j]-mu)^2	
			}
			        SSTreatment <- SSTreatment + n*(y_mean[i]-mu)^2
				SSE <- SSE + (n-1)*std[i]
		}
		#mean square total:
		MST[k] <- SSTreatment/(n-1)
		#mean square error:
		MSE[k] <- SSE/(N-n)
		#p value
		Fisher_value[k] = MST[k]/MSE[k]
		p.value[k] <- pf(Fisher_value[k], n-1, N-n)  
		
		# condition p.value with alpha
		if(p.value[k] <= alpha){
		cnt_number = cnt_number + 1
		}
		
		if(p.value[k] > alpha){
		cnt_numb = cnt_numb + 1
		}
		
		if(Fisher_value[k] > quant){
		a = a+ 1
		}			
	}  
	
	# return value
	return(cat("Count TRUE p_values number when less than or equalt to(<=) alpha(0.05)= ", cnt_number, ", Count False (>0.05) values= ",cnt_numb, "\n"))

}


# Chi square distribution:

chisqaure_Dis <- function(){
	# initilize the mean square total (MST)and mean square error(MSE) 
	MSE <- numeric(1000)
	MST <- numeric(1000)
	p.value <- numeric(1000)
	Fisher_value <- numeric(1000)
	
	# set up the alpha value and initial counting value
	alpha <- 0.05
	cnt_number <- 0
	cnt_numb <- 0
	a <- 0
	# quantile
	quant <- qf(1-alpha, 3, 12)
	

	# create a loop for 1000 times
	for(k in 1:1000){
		cdata <- numeric(0)
		# SSTotal
		SST <- 0
		# SSTreatment
		SSTreatment <- 0
		# sum square error
		SSE <- 0
		n <- 4
		# mean and std
		y_mean <- numeric(n)
		std <- numeric(n)
		
		# now create rnorm for 16 value
		cdata <- rchisq(16, df =1) # degree of freedom 1
		cmu = 1
		sigm = sqrt(2)
		cdata = (cdata-cmu)/sigm
		# create a matrix
		M <- matrix(cdata, n, n)
		N <- length(cdata)
		mu <- mean(cdata)
		
		for(i in 1:n){
			y_mean[i] <- mean(M[i,])
			std[i] <- var(M[i,])
		}

		# now SST define
		for(i in 1:n){
			for(j in 1:n){
				SST <- SST+(M[i,j]-mu)^2	
			}
			        SSTreatment <- SSTreatment + n*(y_mean[i]-mu)^2
				SSE <- SSE + (n-1)*std[i]
		}
		#mean square total:
		MST[k] <- SSTreatment/(n-1)
		#mean square error:
		MSE[k] <- SSE/(N-n)
		#p value
		Fisher_value[k] = MST[k]/MSE[k]
		p.value[k] <- pf(Fisher_value[k], n-1, N-n)  
		
		# condition p.value with alpha
		if(p.value[k] <= alpha){
		cnt_number = cnt_number + 1
		}
		
		if(p.value[k] > alpha){
		cnt_numb = cnt_numb + 1
		}
		
		if(Fisher_value[k] > quant){
		a = a+ 1
		}			
	}  
	
	# return value
	return(cat("Count TRUE p_values number when less than or equalt to(<=) alpha(0.05)= ", cnt_number, ", Count False (>0.05) values= ",cnt_numb, "\n"))
}



## Gamma distribution

gamma_Dis <- function(){
	# initilize the mean square total (MST)and mean square error(MSE) 
	MSE <- numeric(1000)
	MST <- numeric(1000)
	p.value <- numeric(1000)
	Fisher_value <- numeric(1000)
	
	# set up the alpha value and initial counting value
	alpha <- 0.05
	cnt_number <- 0
	cnt_numb <- 0
	a <- 0
	# quantile
	quant <- qf(1-alpha, 3, 12)
	

	# create a loop for 1000 times
	for(k in 1:1000){
		cdata <- numeric(0)
		# SSTotal
		SST <- 0
		# SSTreatment
		SSTreatment <- 0
		# sum square error
		SSE <- 0
		n <- 4
		# mean and std
		y_mean <- numeric(n)
		std <- numeric(n)
		
		# now create rnorm for 16 value
		cdata <- rgamma(16, 2, 1) 
		cmu = 2
		sigm = sqrt(2)
		cdata = (cdata-cmu)/sigm

		# create a matrix called M
		M <- matrix(cdata, n, n)
		N <- length(cdata)
		mu <- mean(cdata)
		
		for(i in 1:n){
			y_mean[i] <- mean(M[i,])
			std[i] <- var(M[i,])
		}

		# now SST define
		for(i in 1:n){
			for(j in 1:n){
				SST <- SST+(M[i,j]-mu)^2	
			}
			        SSTreatment <- SSTreatment + n*(y_mean[i]-mu)^2
				SSE <- SSE + (n-1)*std[i]
		}
		#mean square total:
		MST[k] <- SSTreatment/(n-1)
		#mean square error:
		MSE[k] <- SSE/(N-n)
		#p value
		Fisher_value[k] = MST[k]/MSE[k]
		p.value[k] <- pf(Fisher_value[k], n-1, N-n)  
		
		# condition p.value with alpha
		if(p.value[k] <= alpha){
		cnt_number = cnt_number + 1
		}

		if(p.value[k] > alpha){
		cnt_numb = cnt_numb + 1
		}
		
		if(Fisher_value[k] > quant){
		a = a+ 1
		}			
	}  
	
	# return value
	return(cat("Count TRUE p_values number when less than or equalt to(<=) alpha(0.05)= ", cnt_number, ", Count False (>0.05) values= ",cnt_numb, "\n"))

}

# Comment: if p.values is less than at a significance level of 0.05, we can reject the null hypothesis and conclude that the regression or intercept is significant.

