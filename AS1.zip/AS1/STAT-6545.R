# Min value
    M = function(x){
      mn = Inf  #  any infinity positive real number
      for (i in seq_along(x)) { 
        if (x[i] < mn) mn = x[i]
      }
      return(mn)
    }
    
    
# Max   value
    M2 = function(x){
      mx = -Inf # any infinity negative real number 
      for (i in seq_along(x)) { 
        if (x[i] > mx) mx = x[i]
      }
      return(mx)
    }
    
# sorting function
    s=c(1, 5,3,12,2,4,14,11,9,8,10)
    sort(s,decreasing = FALSE)
    
# standardization
std=function(x){
  m = mean(x)
  s=sd(x)
  z=(x-m)/s
  return(z)
}

# standardization
std1=function(x, m=3, s=1){
  z=(x-m)/s
  return(z)
}

# standardization 
std2=function(x, m=mean(x), s=sd(x)){
  z=(x-m)/s
  return(z)
}
## TMM function
TMM= function(x){
  x= sort(x)
  n=length(x)
  m =mean(x[2:(n-1)])
  return(m)
}

##### quadratic root
# ax^2 +  bx + c = 0
Root = function(a,b,c){
       # calculation
	D <- (b^2-4*a*c)/(2*a)
	if (D>= 0){
	  pos_root = (-b) + sqrt(D)
	  neg_root = (-b) - sqrt(D)
	  cat("positive root", pos_root)
	  cat("\n negative root", neg_root)
  	}else{
  	cat("Nothing-> imagenary number")}
}


### program to the sum of a vector
sum  <- 0
for(i in x){
  sum = sum + i
  cat("the current loop element is: ", i, "\n")
  cat("The sum of x vector: ", sum, "\n")
}

# program to finout sum of  vector with position
x <- c(2,5,6,1,9,4,3)
k <- length(x)
sum <- 0
for (i in 1:k){
  sum = sum + x[i]
}
cat("The cumulative total is",sum,"\n")


## while statement: some problems
# first-one
i <- -1
while(i<10){
	print(i)
	i = i+1
	}

#second-one
 v<- c("Hello","while loop")
 c <- 1

 while (c < 5) {
   print(v)
   c = c + 1
 }

# we can solve while probles as we want
#1. problem is last one? (L, U)

# class 3( Basic R programming)
# Creating Matrix in R
 A = matrix(c(1,2,3,4,5,6), 2,3)
 B = matrix(5:10, nrow=2)
 
	# sum of two matrix
	A + B
	# difference of two vectors
	A - B
  A * B
# Creating a  matrix by R-programming
	M = matrix(1:10, 5,2)
	########### 
	  
## ANOVA - statistacally varience analysis
# efficiency of programming
# Looping with while
# computing the Run Length

	# let x is a vector
	x = c (23,34,21,34,22,32,35,34,40,41,32,44,33,2)
	# set  the L and U value
	L = 20 #and 
	U = 40
	n = length(x)
	out = 0
	i=1
	while(out<1){
		
	}

# Maximum and minimum of a function 
	
	x <- seq(0, 1, .001)
	f =  x^2 -sin(x)
	plot(x,f)
 
	f <- function(x){
	  x^2 - sin(x)
	}
	 a=0
	 c= .382
	 d= .618
	 b= 1
	 r = (sqrt( 5)-1)/2
	if (b==d && c ==d){
	  c =  a+ r*(b-a)
	}



### optim()

fn <- function(x1){
  
x=x1[1]
y=x1[2]
x^2-4*x+y^2-y-x*y}
pa=c(0,0)

optim(c(1,2, fn))
	
