# Solution 4: R-code for Mathematical Invese function:

# continuous inverse transformation:
num_samples <- 7
U <- runif(num_samples)
Fx <- U
x <- sqrt(2*U + 1/4) -1/2
Px <- x
rbind(Px, Fx)
#plot

# plot check:
hist(x, freq=F, xlab='X', main='Generating R.V.')
