# I have writen here an algorithm which I have used to solve this given integration. To estimate theta of this integration, I have used Monte Carlo hit and Miss method that we have done in the class. However we can solve this problem by different way.

# Algorithm:
# step 1: uniformly generate X~U(a=0,b=1) and Y(f(x)) ~ U(f_min,f_max), where f_min and f_max are any values
# step 2: fhm is a function of one variable [f(x) = x^2 * cos(x^2) * exp(-2*x))]
# step 3: over [a,b], f_min and f_max are bounds on fhm
# step 4: Mathematically, f_min <= fhm(x) <= f_max on [a,b]
# stpe 5: n is the number to estimate
# step 6: calculate: sum(Z_sum)/n
# step 7: calculate: hit_miss method <- (Z_sum/n)*(b - a)*(f_max - f_min) + (b - a)*f_min
# stpe 8: calculate: function(fhm, a, b, f_min, f_max, n) for different sample sizes

# Monte-Carlo integration using the hit and miss method: Goal estimate theta
hit_and_miss <- function(fhm, a, b, f_min, f_max, n) {

# create z:
Z_sum <- 0

for (i in 1:n) {
# uniformly X~Unif(a,b)
X <- runif(1, a, b)
# uniformly Y=f(x)~Unif(a,b)
Y <- runif(1, f_min, f_max)
# condition of z eatimation
Z <- (fhm(X) >= Y)
Z_sum <- Z_sum + Z
}

# estimation theta
theta <- (Z_sum/n)*(b - a)*(f_max - f_min) + (b - a)*f_min
return(theta)
}

# f is a given function of one variable:
f <- function(x){
  return(x^2 * cos(x^2) * exp(-2*x))
} 

# Estimation theta using Monte Carlo method for different size:
hit_and_miss(f, 0, 1, -6, 2, 100)
hit_and_miss(f, 0, 1, -6, 2, 130)
hit_and_miss(f, 0, 1, -6, 2, 300)
hit_and_miss(f, 0, 1, -6, 2, 500)
