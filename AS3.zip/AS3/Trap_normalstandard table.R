#solution 1.

# create function:

f <- function(z){
  return(exp(-z^2/2)/sqrt(2*pi))
}

a<- -5
b<- 0
n<-100
h = (b-a)/n

z<- seq(0,3.09, 0.01)
result = 0.5*f(a) + 0.5*f(b)
# trap <- c()
trap<-c()

for (i in seq_along(z)){
  result= result + f(a + i*h)
  #trap = h*result
    trap[i] = h*result
  #cat(trap)
}
  trap
  matrix(trap, ncol = 10, byrow = T)

