
f <- function(x) {x*(1-x)^3}
g <- function(x){return(x)}

genSamp <- function(n,a,b) {
  
 #setting probability using replicated:
  stProbe <- rep(0,n)

 # setting x in the interval:
  x <- seq(a,b, by = 0.01)
 
  # max number M=sup{f(x)/g(X):
  M = max(f(x)/g(x))

  # loop for creating random generation and checking rejecting values:
  for (i in 1:n) {
    repeat{
      x <- runif(1, a, b)
      u <- runif(1,a,b)
      if(u <= (f(x)/(M*g(x)))) {break}
      }
    stProbe[i] <- x
    }

  return(stProbe)
  }

set.seed(121)
# set genSample
test <- genSamp(10000, 0.1, 0.8)
# test mean and varience
mean(test)
var(test)
