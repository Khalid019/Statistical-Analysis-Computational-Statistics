# Bisecton Method:
# set the function: bisecion(x,n)=  -n*log(pi) - sum(log((1 + (x - theta)^2)))

x <- c(1.77, -0.23, 2.76, 3.80, 3.47, 56.75, -1.34, 4.24, -2.44, 3.29, 3.71, -2.40, 4.53,
       0.007, -1.05, -13.87, -2.53, -1.75, 0.27, 43.21)
n <- length(x)

bisec <- function(theta){
 2*sum((x-theta)/(1+(x-theta)^2))
}

# reading the given value of that function:
print("Enter the value of a & b")
a <- as.double(readline(prompt="Enter the value a : "))
b <- as.double(readline(prompt="Enter the value b : "))

bisec_a <- bisec(a)
bisec_b <- bisec(b)

m <- (a+b)/2
i <- 0

if(bisec_a * bisec_b > 0){
	print("Entering the value is invalid")
}

while( abs((b-a)/2) > 0.0001){
	i <- i + 1
	bisec_a <- bisec(a)
	bisec_b <- bisec(b)
	bisec_m <- bisec(m)
	print(paste("Iteration: ", i))
	print(paste("Root: ", m))
	if(bisec_a * bisec_m < 0){
	b = m	
	}else{
	a = m	
	}
	m = (a+b)/2
}

