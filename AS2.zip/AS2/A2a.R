#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Given x vector:
x <- c(1.77, -0.23, 2.76, 3.80, 3.47, 56.75, -1.34, 4.24, -2.44, 3.29, 3.71, -2.40, 4.53,
       0.007, -1.05, -13.87, -2.53, -1.75, 0.27, 43.21)
n=length(x)

cauchymle=function(x, starting_value, tole){

thetahatzero=starting_value
cat ("print the starting value of thetahatzero=", thetahatzero, "\n")

# Compute first deriviative of log likelihood
#func = -n*log(pi) - sum(log(1 + (x-thetahatzero)^2))

firstder= 2*sum((x-thetahatzero)/(1+(x-thetahatzero)^2))
secondder= 2*sum(((x-thetahatzero)^2-1)/(1+(x-thetahatzero)^2)^2)
thetahatnew = thetahatzero - (firstder/secondder)

# Continue Newton-Rapson method until the first derivative
# of the likelihood is within toler of 0.001
it <- 0

while(abs(firstder) > tole & it < 20){

thetahatzero=thetahatnew
firstder=2*sum((x-thetahatzero)/(1+(x-thetahatzero)^2))
secondder=2*sum(((x-thetahatzero)^2-1)/(1+(x-thetahatzero)^2)^2)
thetahatnew=thetahatzero- (firstder/secondder)

it <- it + 1

}
list(thetahat=thetahatnew, iteration = it);
}

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

