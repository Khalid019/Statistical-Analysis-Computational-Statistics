library(dplyr)
# Read CSV into R
MyData <- read.csv("~/Desktop/As2/sfo2018datafile.csv", header=TRUE, sep=",")



MyData <- read.csv("~/Desktop/As2/sfo2018datafile.csv",header=TRUE, sep=",")
# Print the column names:
colnames(MyData, do.NULL = FALSE)
#select multiple columns by name
req <- MyData[, c("RESPNUM", "Q7ALL")]
View(req)
dim(req)

# Play with Q7ALL:
Q7ALL <- MyData[, c("Q7ALL")]
Q7ALL <- MyData[, "Q7ALL"]
