#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Given x vector:
x <- c(1.77, -0.23, 2.76, 3.80, 3.47, 56.75, -1.34, 4.24, -2.44, 3.29, 3.71, -2.40, 4.53,
       0.007, -1.05, -13.87, -2.53, -1.75, 0.27, 43.21)
n=length(x)

sec <- function(theta){
	 2*sum((x-theta)/(1+(x-theta)^2))
	}
secant <- function(sec, theta0, theta1, tole){

f0= sec(theta0)
f1= sec(theta1)
#wanted=10^-8;
iter=0;

while( abs(theta1-theta0) >= tole & iter<30){
    iter=iter+1
    F =(theta1-theta0)/(f1-f0);
    xnew=theta1-F*f1
    if(abs(theta1 - xnew) > abs(xnew - theta0)){
	theta1 = xnew}else {
      theta0 = xnew
     }	
    
}
list(thetahat=xnew, iteration = iter);
}

#  compute the time:
#system.time(source('~/Desktop/As2/A2c.R'))
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>






